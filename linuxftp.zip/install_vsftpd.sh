#!/bin/bash

# Install vsftpd
sudo apt update
sudo apt install vsftpd -y

# Create FTP User to Set up FTP Server
sudo adduser ftpuser

# You should disable their SSH access if you only want ftpuser to log in via FTP
echo "DenyUsers ftpuser" | sudo tee -a /etc/ssh/sshd_config

# Restart the SSH service
sudo service sshd restart

# Add the user to the allowed FTP users list
echo "ftpuser" | sudo tee -a /etc/vsftpd.user_list

# Create the FTP directory tree and set the correct permissions
sudo mkdir -p /home/ftpuser/ftp/upload
sudo chmod 550 /home/ftpuser/ftp
sudo chmod 750 /home/ftpuser/ftp/upload
sudo chown -R ftpuser: /home/ftpuser/ftp

# Upload Files on Web Server Using FTP Server
sudo usermod -d /var/www ftpuser
sudo chown ftpuser:ftpuser /var/www/html

# Rename the orginal config file
sudo mv /etc/vsftpd.conf /etc/vsftpd.conf.bak

# Configuration of /etc/vsftpd.conf
cat << EOF | sudo tee /etc/vsftpd.conf
listen=NO
listen_ipv6=YES
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
connect_from_port_20=YES
chroot_local_user=YES
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
force_dot_files=YES
pasv_min_port=40000
pasv_max_port=50000
EOF

# Restart vsftpd service
sudo systemctl restart vsftpd

# Securing Transmissions with SSL/TLS
sudo openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -keyout /etc/ssl/private/vsftpd.pem -out /etc/ssl/private/vsftpd.pem -subj "/C=DK/ST=MIDT/L=IKAST/O=AUM/OU=AUM/CN=AUM.local/emailAddress=AUM@email.com"

# Configuration add ssl to /etc/vsftpd.conf
cat << EOF | sudo tee -a /etc/vsftpd.conf

ssl_enable=YES
rsa_cert_file=/etc/ssl/private/vsftpd.pem
rsa_private_key_file=/etc/ssl/private/vsftpd.pem
allow_anon_ssl=NO
force_local_data_ssl=YES
force_local_logins_ssl=YES
ssl_tlsv1=YES
ssl_sslv2=NO
ssl_sslv3=NO
require_ssl_reuse=NO
ssl_ciphers=HIGH
EOF

# Restart vsftpd service
sudo systemctl restart vsftpd
