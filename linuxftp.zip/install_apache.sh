#!/bin/bash

# Install apache
sudo apt update
sudo apt install apache2 -y

# To stop your web server
sudo systemctl stop apache2

# To start the web server when it is stopped
sudo systemctl start apache2

# To re-enable the service to start up at boot
sudo systemctl enable apache2

# Setting Up Virtual Hosts (Recommended)
sudo mkdir /var/www/your_domain
sudo chown -R $USER:$USER /var/www/your_domain
sudo chmod -R 755 /var/www/your_domain

# create a sample index.html page using nano or your favorite editor:
cat << EOF | sudo tee /var/www/your_domain/index.html
<html>
    <head>
        <title>Welcome to Your_domain!</title>
    </head>
    <body>
        <h1>Success!  Tillykke vi har hermed kunne opsætte apache!</h1>
    </body>
</html>
EOF

# In order for Apache to serve this content, it’s necessary to create a virtual host file
cat << EOF | sudo tee /etc/apache2/sites-available/your_domain.conf
<VirtualHost *:80>
    ServerAdmin webmaster@localhost
    ServerName your_domain
    ServerAlias www.your_domain
    DocumentRoot /var/www/your_domain
    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF

# Enable the file with the a2ensite tool
sudo a2ensite your_domain.conf

# Disable the default site defined in 000-default.conf
sudo a2dissite 000-default.conf

# Next, let’s test for configuration errors
sudo apache2ctl configtest

# You should receive the following output
# Syntax OK

# Restart Apache to implement your changes
sudo systemctl restart apache2

# Server Logs
# /var/log/apache2/access.log: By default, every request to your web server in here
# /var/log/apache2/error.log: By default, all errors are recorded in here